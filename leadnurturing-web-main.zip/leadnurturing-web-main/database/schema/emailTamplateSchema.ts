import mongoose from "mongoose";

const emailTamplateSchema = new mongoose.Schema({
    campaignId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "campaign",
        required: true
    },
    email1:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    email2:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    email3:{
        type: mongoose.Schema.Types.String,
        required: true
    },
});

export const EMAILTAMPLATE = mongoose.model("emailTamplates", emailTamplateSchema);