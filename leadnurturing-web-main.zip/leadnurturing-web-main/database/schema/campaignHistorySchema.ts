import mongoose from "mongoose";

const campaignHistorySchema = new mongoose.Schema({
    campaignid : {
        type: mongoose.Schema.Types.ObjectId,
        ref: "campaign",
        required: true
    },
    leadid:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "leads",
        required: true
    },
    status:{
        type: mongoose.Schema.Types.String,
        required: true
    },
});

export const CAMPAIGNHISTORY = mongoose.model("campaignHistory", campaignHistorySchema);