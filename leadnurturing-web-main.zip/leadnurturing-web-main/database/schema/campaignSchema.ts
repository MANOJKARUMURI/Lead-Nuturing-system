    import mongoose from "mongoose";

    const campaignSchema = new mongoose.Schema({
    name: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    type: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    leads: [
        {
        type: mongoose.Schema.Types.ObjectId,
        ref: "leads",
        },
    ],
    emails: [
        {
        type: mongoose.Schema.Types.String,
        require: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"],
        },
    ],
    LinkedIn: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Facebook: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Pinterest: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Youtube: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Thread: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Instagram: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    Twitter: {
        type: mongoose.Schema.Types.String,
        required: true,
    },
    status:{
        type: mongoose.Schema.Types.String,
        default: "created",
        required: true,
    },
    startedAt: {
        type: Date,
        default: Date.now,
    },
    });

    export const CAMPAIGN = mongoose.model("campaign", campaignSchema);
