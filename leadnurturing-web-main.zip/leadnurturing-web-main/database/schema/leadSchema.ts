import mongoose from "mongoose";

const leadSchema = new mongoose.Schema({
    firstName: {
        type: mongoose.Schema.Types.String,
        required: true
    },
    lastName:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    companyName:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    emailPrimary:{
        type: mongoose.Schema.Types.String,
        required: true,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    email1:{
        type: mongoose.Schema.Types.String,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    email2:{
        type: mongoose.Schema.Types.String,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    email3:{
        type: mongoose.Schema.Types.String,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    email4:{
        type: mongoose.Schema.Types.String,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    email5:{
        type: mongoose.Schema.Types.String,
        lowercase: true,
        match: [/^\S+@\S+\.\S+$/, "Invalid email format"]
    },
    address:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    country:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    LinkedIn:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Facebook:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Pinterest:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Youtube:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Thread:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Instagram:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Twitter:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    companyWebsite:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    contact:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Product:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    emailAlias:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    Status:{
        type: mongoose.Schema.Types.String,
        required: true
    },
    isSafe:{
        type: mongoose.Schema.Types.Boolean,
        required: true
    },
});

export const LEADS = mongoose.model("leads", leadSchema);