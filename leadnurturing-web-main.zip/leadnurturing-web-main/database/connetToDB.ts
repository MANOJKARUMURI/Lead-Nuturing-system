import mongoose from "mongoose";


export const CONNECTDB = async () => {
    const url : string  = process.env.MONGODB_URL as string

    if(!url){
        console.log("No MongoDB Url")
        return;
    }
    try{
        await mongoose.connect(url);
        console.log("MongoDB is connected")
    }catch(err){
        console.log("mongoDb Connection error", err)
    }
}