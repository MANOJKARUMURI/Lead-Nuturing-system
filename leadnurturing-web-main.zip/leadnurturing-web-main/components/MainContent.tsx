"use client";

import React from "react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/context/SidebarContext";

export default function MainContent({ children }: { children: React.ReactNode }) {
  const { isCollapsed } = useSidebar();

  return (
    <main
      className={cn(
        "p-6 bg-gray-100 dark:bg-gray-900 min-h-screen transition-all duration-300",
        isCollapsed ? "ml-16" : "ml-64"
      )}
    >
      <div className="pt-4">
        {children}
      </div>
    </main>
  );
}