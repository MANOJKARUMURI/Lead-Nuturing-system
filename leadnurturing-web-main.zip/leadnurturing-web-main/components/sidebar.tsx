"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Megaphone, Users, ChevronLeft, ChevronRight, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/context/SidebarContext";

type NavItemProps = {
  href: string;
  icon: React.ReactNode;
  label: string;
  isCollapsed: boolean;
};

const NavItem = ({ href, icon, label, isCollapsed }: NavItemProps) => {
  const pathname = usePathname();
  const isActive = pathname === href;
  
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg transition duration-200",
        isActive 
          ? "bg-primary/10 text-white font-medium" 
          : "hover:bg-gray-800 text-gray-300 hover:text-white",
        isCollapsed && "justify-center px-2"
      )}
    >
      <div className={isActive ? "text-white" : "text-gray-400"}>
        {icon}
      </div>
      {!isCollapsed && <span>{label}</span>}
    </Link>
  );
};

const Sidebar = () => {
  const { isCollapsed, toggleSidebar } = useSidebar();

  return (
    <div className={cn(
      "fixed top-0 left-0 h-screen bg-gray-900 text-white flex flex-col p-4 transition-all duration-300 z-10",
      isCollapsed ? "w-16" : "w-64"
    )}>
      {/* Toggle collapse button */}
      <button 
        onClick={toggleSidebar}
        className="absolute -right-3 top-12 bg-gray-800 rounded-full p-1 border border-gray-700 text-gray-400 hover:text-white"
      >
        {isCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
      </button>

      {/* Branding */}
      <div className={cn(
        "font-bold text-center py-4 border-b border-gray-700",
        isCollapsed ? "text-sm" : "text-xl"
      )}>
        {isCollapsed ? "EW" : "Ecowoodies"}
      </div>

      {/* Main Navigation */}
      <div className="flex flex-col gap-2 mt-4 flex-1 overflow-y-auto">
        <div className="mb-2 px-3">
          {!isCollapsed && <p className="text-xs uppercase text-gray-500 font-medium">Main</p>}
        </div>
        
        <NavItem 
          href="/" 
          icon={<Home size={20} />} 
          label="Dashboard" 
          isCollapsed={isCollapsed} 
        />
        <NavItem 
          href="/campaigns" 
          icon={<Megaphone size={20} />} 
          label="Campaigns" 
          isCollapsed={isCollapsed} 
        />
        <NavItem 
          href="/lead" 
          icon={<Users size={20} />} 
          label="Leads" 
          isCollapsed={isCollapsed} 
        />
      </div>

      {/* Footer/Settings Navigation */}
      <div className="mt-auto border-t border-gray-800 pt-4">
        <NavItem 
          href="/settings" 
          icon={<Settings size={20} />} 
          label="Settings" 
          isCollapsed={isCollapsed} 
        />
      </div>
    </div>
  );
};

export default Sidebar;
