"use client";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";

// ✅ Format Dates Before Rendering
const formatDate = (dateString: string) => {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(dateString));
};

// ✅ Static Data (For UI Testing)
const leads = [
  {
    id: "1",
    Name: "John Doe",
    Email: "john.doe@example.com",
    Status: "New",
    Source: "LinkedIn",
    CreatedAt: "2024-02-20T14:00:00Z",
  },
  {
    id: "2",
    Name: "Jane Smith",
    Email: "jane.smith@example.com",
    Status: "Contacted",
    Source: "Website Form",
    CreatedAt: "2024-02-18T10:30:00Z",
  },
];

export default function LeadTable() {
  return (
    <div className="p-6 border rounded-xl shadow-sm bg-white max-w-5xl mx-auto">
      <h2 className="text-2xl font-semibold text-gray-900 mb-4">📋 Leads</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-left text-gray-600">👤 Name</TableHead>
            <TableHead className="text-left text-gray-600">📧 Email</TableHead>
            <TableHead className="text-left text-gray-600">📅 Created</TableHead>
            <TableHead className="text-left text-gray-600">🔄 Status</TableHead>
            <TableHead className="text-left text-gray-600">🌍 Source</TableHead>
            <TableHead className="text-right text-gray-600">⚙️</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leads.map((lead) => (
            <TableRow key={lead.id} className="hover:bg-gray-50 transition">
              <TableCell className="font-medium text-gray-900">{lead.Name}</TableCell>
              <TableCell className="text-gray-700">{lead.Email}</TableCell>
              <TableCell className="text-gray-500">{formatDate(lead.CreatedAt)}</TableCell>
              <TableCell>
                <Badge
                  variant={lead.Status === "New" ? "success" : "warning"}
                  className="px-2 py-1 rounded-md text-sm"
                >
                  {lead.Status}
                </Badge>
              </TableCell>
              <TableCell className="text-gray-700">{lead.Source}</TableCell>
              <TableCell className="text-right">
                <LeadActions leadId={lead.id} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// ✅ Actions Menu (Moved to Separate Component)
function LeadActions({ leadId }: { leadId: string }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="text-gray-500 hover:bg-gray-100">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-32">
        <DropdownMenuItem onClick={() => alert(`Viewing ${leadId}`)}>👁️ View</DropdownMenuItem>
        <DropdownMenuItem onClick={() => alert(`Editing ${leadId}`)}>✏️ Edit</DropdownMenuItem>
        <DropdownMenuItem className="text-red-500" onClick={() => alert(`Deleting ${leadId}`)}>
          ❌ Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
