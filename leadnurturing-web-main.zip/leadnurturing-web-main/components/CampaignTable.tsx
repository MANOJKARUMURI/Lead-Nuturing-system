"use client";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";

// ✅ Format Dates Before Rendering
const formatDate = (dateString: string) => {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(dateString));
};

// ✅ Static Data (For UI Testing)
const campaigns = [
  {
    id: "1",
    CampaignName: "Black Friday Sale",
    CampaignType: "E-commerce",
    Leads: "1342",
    Emails: "Active",
    Socials: ["Facebook", "Twitter", "Instagram"],
    StartedAt: "2024-01-15T10:00:00Z",
  },
  {
    id: "2",
    CampaignName: "Summer Giveaway",
    CampaignType: "Marketing",
    Leads: "758",
    Emails: "Inactive",
    Socials: ["LinkedIn", "YouTube"],
    StartedAt: "2024-02-10T09:30:00Z",
  },
];

export default function CampaignTable() {
  return (
    <div className="p-6 border rounded-xl shadow-sm bg-white max-w-5xl mx-auto">
      <h2 className="text-2xl font-semibold text-gray-900 mb-4">📊 Campaigns</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-left text-gray-600">📌 Name</TableHead>
            <TableHead className="text-left text-gray-600">📢 Type</TableHead>
            <TableHead className="text-left text-gray-600">📅 Started</TableHead>
            <TableHead className="text-left text-gray-600">🎯 Leads</TableHead>
            <TableHead className="text-left text-gray-600">📧 Email</TableHead>
            <TableHead className="text-left text-gray-600">📱 Social Media</TableHead>
            <TableHead className="text-right text-gray-600">⚙️</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {campaigns.map((campaign) => (
            <TableRow key={campaign.id} className="hover:bg-gray-50 transition">
              <TableCell className="font-medium text-gray-900">{campaign.CampaignName}</TableCell>
              <TableCell className="text-gray-700">{campaign.CampaignType}</TableCell>
              <TableCell className="text-gray-500">{formatDate(campaign.StartedAt)}</TableCell>
              <TableCell>
                <Badge variant="outline" className="text-gray-700 border-gray-300">
                  {campaign.Leads}
                </Badge>
              </TableCell>
              <TableCell>
                <Badge
                  variant={campaign.Emails === "Active" ? "success" : "destructive"}
                  className="px-2 py-1 rounded-md text-sm"
                >
                  {campaign.Emails}
                </Badge>
              </TableCell>
              <TableCell className="space-x-1">
                {campaign.Socials.map((social, index) => (
                  <Badge key={index} variant="secondary" className="bg-gray-100 text-gray-800">
                    {social}
                  </Badge>
                ))}
              </TableCell>
              <TableCell className="text-right">
                <CampaignActions campaignId={campaign.id} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// ✅ Actions Menu (Moved to Separate Component)
function CampaignActions({ campaignId }: { campaignId: string }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="text-gray-500 hover:bg-gray-100">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-32">
        <DropdownMenuItem onClick={() => alert(`Editing ${campaignId}`)}>✏️ Edit</DropdownMenuItem>
        <DropdownMenuItem className="text-red-500" onClick={() => alert(`Deleting ${campaignId}`)}>
          ❌ Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
