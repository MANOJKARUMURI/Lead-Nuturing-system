"use client";

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, BarChart, Bar, ResponsiveContainer } from 'recharts';

export default function Home() {
  // Temporary static data for UI development
  const campaigns = [
    {
      id: "1",
      name: "Summer Campaign",
      type: "Email",
      status: "active",
      startedAt: "2024-01-15",
      leads: Array(125).fill(null),
      performance: [
        { month: 'Jan', leads: 45 },
        { month: 'Feb', leads: 85 },
        { month: 'Mar', leads: 125 }
      ]
    },
    {
      id: "2",
      name: "Social Media Push",
      type: "Social",
      status: "inactive",
      startedAt: "2024-02-01",
      leads: Array(89).fill(null),
      performance: [
        { month: 'Jan', leads: 30 },
        { month: 'Feb', leads: 60 },
        { month: 'Mar', leads: 89 }
      ]
    }
  ];

  const mockLeadStatus = {
    "New": 45,
    "Contacted": 78,
    "Qualified": 56,
    "Converted": 35
  };

  const totalLeads = campaigns.reduce((acc, campaign) => acc + campaign.leads.length, 0);
  const activeCampaigns = campaigns.filter(campaign => campaign.status === "active").length;

  // Prepare data for charts
  const leadStatusData = Object.entries(mockLeadStatus).map(([name, value]) => ({ name, value }));
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  const campaignTypeData = [
    { name: 'Active', value: activeCampaigns },
    { name: 'Inactive', value: campaigns.length - activeCampaigns }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Master Dashboard</h1>
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Total Campaigns</h3>
          <p className="text-3xl font-bold">{campaigns.length}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Active Campaigns</h3>
          <p className="text-3xl font-bold">{activeCampaigns}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Total Leads</h3>
          <p className="text-3xl font-bold">{totalLeads}</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Campaign Performance Line Chart */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Campaign Performance</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={campaigns[0].performance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="leads" stroke="#8884d8" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lead Status Distribution Pie Chart */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Lead Status Distribution</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={leadStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {leadStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Campaigns */}
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <h2 className="text-xl font-bold mb-4">Recent Campaigns</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3">Name</th>
                <th className="text-left py-3">Type</th>
                <th className="text-left py-3">Status</th>
                <th className="text-left py-3">Leads</th>
                <th className="text-left py-3">Started</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.slice(0, 5).map((campaign: any) => (
                <tr key={campaign.id} className="border-b hover:bg-gray-50">
                  <td className="py-3">{campaign.name}</td>
                  <td className="py-3">{campaign.type}</td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-full text-sm ${campaign.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                      {campaign.status}
                    </span>
                  </td>
                  <td className="py-3">{campaign.leads.length}</td>
                  <td className="py-3">{new Date(campaign.startedAt).toISOString().split('T')[0]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Campaign Type Distribution Bar Chart */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-4">Campaign Status Distribution</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={campaignTypeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function getLeadStatusDistribution(campaigns: any[]) {
  const distribution: { [key: string]: number } = {};
  
  campaigns.forEach(campaign => {
    campaign.leads.forEach((lead: any) => {
      distribution[lead.Status] = (distribution[lead.Status] || 0) + 1;
    });
  });

  return distribution;
}