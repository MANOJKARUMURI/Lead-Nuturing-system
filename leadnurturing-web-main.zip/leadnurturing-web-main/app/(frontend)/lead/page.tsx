import React from 'react'
import LeadTable from '@/components/leadTable'

const page = () => {
  return (
    <div className="container mx-auto mt-10">
          <LeadTable />
        </div>
  )
}

export default page