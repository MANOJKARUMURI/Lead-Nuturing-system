"use client";

import  CampaignTable from "@/components/CampaignTable";

export default function Home() {
  return (
    <div className="container mx-auto mt-10">
      <CampaignTable />
    </div>
  );
}