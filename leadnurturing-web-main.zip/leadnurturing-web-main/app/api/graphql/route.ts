import { ApolloServer } from "@apollo/server";
import { startServerAndCreateNextHandler } from "@as-integrations/next";
import { NextRequest } from "next/server";
import { CONNECTDB } from "@/database/connetToDB"
import { resolvers } from "@/graphql/resolvers/resolvers";
import { typeDefs } from "@/graphql/typeDefs/typeDefs";

await CONNECTDB();

const server = new ApolloServer({ typeDefs, resolvers });
const handler = startServerAndCreateNextHandler<NextRequest>(server);

export { handler as GET, handler as POST };
