import { NextRequest, NextResponse } from "next/server";
import { CONNECTDB } from "@/database/connetToDB"


export const GET = async ( req: NextRequest ) => {
    await CONNECTDB()
    return new NextResponse(JSON.stringify({ message: "server is running" }), {status: 200});
}