import { CAMPAIGN } from "@/database/schema/campaignSchema";
import { LEADS } from "@/database/schema/leadSchema";
interface CampaignInput {
    name: string;
    type: string;
    leads: string[];
    emails: string[];
    LinkedIn: string;
    Facebook: string;
    Pinterest: string;
    Youtube: string;
    Thread: string;
    Instagram: string;
    Twitter: string;
}

export const campaignResolver = {
    Query: {
        getCampaigns: async () => {
            try {
                const campaigns = await CAMPAIGN.find().populate("leads");
                return campaigns;
            } catch (err) {
                console.error("CAMPAIGN_GET_ERROR", err);
                return "Internal Server Error";
            }
        },
        getCampaign: async (_: any, { id }: { id: string }) => {
            try {
                const campaign = await CAMPAIGN.findById(id).populate("leads");
                if (!campaign) return "No Campaign Found";
                return campaign;
            } catch (err) {
                console.error("CAMPAIGN_ID_GET_ERROR", err);
                return "Internal Server Error";
            }
        },
    },
    Mutation: {
        createCampaign: async (_: any, { input }: { input: CampaignInput }) => {
            try {
                const leads = await LEADS.find({ _id: { $in: input.leads } });

                const newCampaign = new CAMPAIGN({
                    name: input.name,
                    type: input.type,
                    leads: leads,
                    emails: input.emails,
                    LinkedIn: input.LinkedIn,
                    Facebook: input.Facebook,
                    Pinterest: input.Pinterest,
                    Youtube: input.Youtube,
                    Thread: input.Thread,
                    Instagram: input.Instagram,
                    Twitter: input.Twitter,
                });

                await newCampaign.save();
                return newCampaign;
            } catch (err) {
                console.error("CAMPAIGN_CREATE_ERROR", err);
                return "Internal Server Error";
            }
        },
    }
};