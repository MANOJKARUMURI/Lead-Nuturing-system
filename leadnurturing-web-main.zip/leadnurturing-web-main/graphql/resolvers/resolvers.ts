import { leadResolver } from "./leadResolver";
import { campaignResolver } from "./campaignResolver";

export const resolvers = [leadResolver, campaignResolver];