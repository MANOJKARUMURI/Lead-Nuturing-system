import { LEADS } from "@/database/schema/leadSchema"

interface LeadInput {
    firstName: string;
    lastName: string;
    companyName: string;
    emailPrimary: string;
    email1?: string;
    email2?: string;
    email3?: string;
    email4?: string;
    email5?: string;
    address: string;
    country: string;
    LinkedIn: string;
    Facebook: string;
    Pinterest: string;
    Youtube: string;
    Thread: string;
    Instagram: string;
    Twitter: string;
    companyWebsite: string;
    contact: string;
    Product: string;
    emailAlias: string;
    Status: string;
    isSafe: boolean;
}


export const leadResolver = {
    Query:{
        getLeads: async () => {
            try{
                const Leads= await LEADS.find();
                return Leads
            }catch(err){
                console.log("LEAD_GET_ERROR",err)
                return "Internal Server Error"
            }
        },
    },

    Mutation : {
        addLead: async (_: any, { input }: { input: LeadInput }) => {
            try {
                const newLead = new LEADS({
                    firstName: input.firstName,
                    lastName: input.lastName,
                    companyName: input.companyName,
                    emailPrimary: input.emailPrimary,
                    email1: input.email1,
                    email2: input.email2,
                    email3: input.email3,
                    email4: input.email4,
                    email5: input.email5,
                    address: input.address,
                    country: input.country,
                    LinkedIn: input.LinkedIn,
                    Facebook: input.Facebook,
                    Pinterest: input.Pinterest,
                    Youtube: input.Youtube,
                    Thread: input.Thread,
                    Instagram: input.Instagram,
                    Twitter: input.Twitter,
                    companyWebsite: input.companyWebsite,
                    contact: input.contact,
                    Product: input.Product,
                    emailAlias: input.emailAlias,
                    Status: input.Status,
                    isSafe: input.isSafe
                });
        
                await newLead.save();
                return newLead;
            } catch (err) {
                console.error("LEAD_ADD_ERROR", err);
                return "Internal Server Error";
            }
        },        
    }
}