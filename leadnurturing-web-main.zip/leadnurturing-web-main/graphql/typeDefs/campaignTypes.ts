import { gql } from "graphql-tag";

export const campaignTypedefs = gql `
    type Lead {
        id: ID!
        firstName: String!
        lastName: String!
        companyName: String!
        emailPrimary: String!
        email1: String
        email2: String
        email3: String
        email4: String
        email5: String
        address: String!
        country: String!
        LinkedIn: String!
        Facebook: String!
        Pinterest: String!
        Youtube: String!
        Thread: String!
        Instagram: String!
        Twitter: String!
        companyWebsite: String!
        contact: String!
        Product: String!
        emailAlias: String!
        Status: String!
        isSafe: Boolean!
    }

    type Campaign {
        id: ID!
        name: String!
        type: String!
        leads: [Lead!]!
        emails: [String!]!
        LinkedIn: String!
        Facebook: String!
        Pinterest: String!
        Youtube: String!
        Thread: String!
        Instagram: String!
        Twitter: String!
        startedAt: String!
    }

    input CampaignInput {
        name: String!
        type: String!
        leads: [ID!]!
        emails: [String!]!
        LinkedIn: String!
        Facebook: String!
        Pinterest: String!
        Youtube: String!
        Thread: String!
        Instagram: String!
        Twitter: String!
    }

    type Query {
        getCampaigns: [Campaign]
        getCampaign(id: ID!): Campaign
    }

    type Mutation {
        createCampaign(input: CampaignInput!): Campaign
        updateCampaign(id: ID!, input: CampaignInput!): Campaign
        deleteCampaign(id: ID!): String
    }
`;
