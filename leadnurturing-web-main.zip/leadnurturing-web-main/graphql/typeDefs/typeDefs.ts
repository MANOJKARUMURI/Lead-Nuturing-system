import { leadTypedefs } from "./leadTypes";
import { campaignTypedefs } from "./campaignTypes";

export const typeDefs = [leadTypedefs, campaignTypedefs];