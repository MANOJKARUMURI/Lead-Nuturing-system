import { gql } from "graphql-tag";

export const leadTypedefs =  gql `
    type Lead {
        id: ID!
        firstName: String!
        lastName: String!
        companyName: String!
        emailPrimary: String!
        email1: String
        email2: String
        email3: String
        email4: String
        email5: String
        address: String!
        country: String!
        LinkedIn: String!
        Facebook: String!
        Pinterest: String!
        Youtube: String!
        Thread: String!
        Instagram: String!
        Twitter: String!
        companyWebsite: String!
        contact: String!
        Product: String!
        emailAlias: String!
        Status: String!
        isSafe: Boolean!
    }

    input LeadInput {
        firstName: String!
        lastName: String!
        companyName: String!
        emailPrimary: String!
        email1: String
        email2: String
        email3: String
        email4: String
        email5: String
        address: String!
        country: String!
        LinkedIn: String!
        Facebook: String!
        Pinterest: String!
        Youtube: String!
        Thread: String!
        Instagram: String!
        Twitter: String!
        companyWebsite: String!
        contact: String!
        Product: String!
        emailAlias: String!
        Status: String!
        isSafe: Boolean!
    }
    
    type Query {
        getLeads: [Lead]
        getLead(id: ID!): Lead
    }

    type Mutation{
        addLead(input: LeadInput!): Lead
        updateLead(id: ID!, input: LeadInput!): Lead
        deleteLead(id: ID!): String
    }
`;